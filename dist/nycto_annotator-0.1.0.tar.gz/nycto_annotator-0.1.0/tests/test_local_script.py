# from auto_annotator.auto_annotate import AutoAnnotator

# def test_auto_annotate():
#     input_folder = "/mnt/nvme1/niharika/Test/Python-Package/tests/input"
#     output_folder = "/mnt/nvme1/niharika/Test/Python-Package/tests/output"
#     model_name = "grounding_dino"
#     classes_prompt = {"person": "person", "car": "car"}
#     annotator = AutoAnnotator(model_name)
#     annotator.run(input_folder, output_folder, classes_prompt)

# if __name__ == "__main__":
#     test_auto_annotate()
    

