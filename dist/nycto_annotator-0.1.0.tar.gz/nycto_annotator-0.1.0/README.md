# Auto Annotator

Package for Auto annotation using different models
